import pygame as _pg

# Инициализация Pygame
def init():
    """Инициализирует все модули PyGaming"""
    return _pg.init()

def quit():
    """Завершает работу всех модулей PyGaming"""
    _pg.quit()

# Подмодули
display = _pg.display
draw = _pg.draw
event = _pg.event
time = _pg.time
image = _pg.image
font = _pg.font
mixer = _pg.mixer

# Дополнительные упрощенные функции
def set_window_title(title):
    """Устанавливает заголовок окна"""
    display.set_caption(title)

def create_window(width, height, title="PyGaming Window"):
    """Создает окно с указанными размерами и заголовком"""
    screen = display.set_mode((width, height))
    set_window_title(title)
    return screen