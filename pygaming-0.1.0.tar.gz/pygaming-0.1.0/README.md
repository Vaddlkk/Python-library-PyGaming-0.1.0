# PyGaming

Простая обертка вокруг Pygame для более удобного создания игр на Python.

## Установка

Установите PyGaming с помощью pip:

```bash
pip install pygaming